import os
import shutil
import re

os.chdir("../")
src_files = os.listdir("IN-gov-txts")
p = re.compile('.*?_', re.MULTILINE | re.DOTALL)
# e = re.compile('\d', re.MULTILINE | re.DOTALL) # digits
d = re.compile('[^a-zA-Z]', re.MULTILINE | re.DOTALL)
myfile = ''
for doc in src_files:
    file = open("IN-gov-txts/"+doc, 'r')
    f = file.read()
    f = p.sub('', f)
    f = d.sub('', f)
    myfile = myfile + f + '\n'
    file.close()
z = open("IN-gov-clean.txt", 'w')
z.write(myfile)
z.close()

# create dictionary from myfile text
# from collections import defaultdict


# #create list of unique words from myfile
# def get_word_space(data):
#     word_space = ''
#     data = data.split()
#     for w in data:
#         if len(word_space) == 0:
#             word_space = w
#         elif w not in word_space:
#             word_space = word_space + ', ' + w
#         else:
#             continue
#     return word_space

# INOpinList = get_word_space(myfile)
# #count number of unique words in list
# print("length is ", len(INOpinList))

# #write list to a text file
# os.chdir("/Users/KristinDay/Desktop")
# z = open('INOpinList.txt', "w", newline='')
# z.write(INOpinList)
# z.close()
